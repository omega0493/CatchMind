package com.client;



public class mainClass {
	public static void main(String[] args) {
		new ClientController();

	}
}